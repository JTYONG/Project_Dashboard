/* SQUARE — Recommendation library, education snippets, referral content.
 * Each recommendation follows the seven-field structure used throughout this
 * project: trigger, issue, recommendation, why, benefit, precaution, follow-up.
 */
window.SQ = window.SQ || {};

SQ.recommendations = [
  {
    code: "REC_CV_BP_TRACK",
    domain: "cardiovascular",
    when: (fh) => fh.cv.bpCategoryRank >= 2, // At-risk/high-normal or above
    issue: "Blood pressure above the optimal range",
    action: "Track your blood pressure at home twice daily for 7 days using a validated monitor, seated and rested.",
    why: "A single reading is a screening result, not confirmed hypertension — home readings establish whether the pattern is persistent.",
    benefit: "Confirms whether follow-up with a clinician is warranted and gives them a full week of data.",
    precaution: "Use a validated upper-arm monitor; readings taken immediately after exercise, caffeine or stress can be misleadingly high.",
    followUp: "Bring your 7-day log to your next review.",
    category: "monitoring", weight: 95,
  },
  {
    code: "REC_CV_LIPID_DIET",
    domain: "cardiovascular",
    when: (fh) => fh.cv.ldl >= 3.4 || fh.cv.apobFlag,
    issue: "LDL cholesterol / ApoB above the goal linked to your risk category",
    action: "Increase soluble fibre and improve dietary fat quality — oats, legumes, vegetables, and unsaturated oils in place of saturated fat.",
    why: "Excess saturated fat and low fibre intake are common contributors to elevated LDL-cholesterol and particle burden.",
    benefit: "May improve LDL-C, non-HDL-C and ApoB over 8–12 weeks alongside other lifestyle changes.",
    precaution: "Dietary advice may need modification for other medical conditions — discuss significant changes with a healthcare professional.",
    followUp: "Repeat a fasting lipid panel in 8–12 weeks.",
    category: "nutrition", weight: 88,
  },
  {
    code: "REC_CV_ACTIVITY",
    domain: "cardiovascular",
    when: () => true,
    issue: "General cardiovascular and metabolic health",
    action: "Build towards at least 150 minutes of moderate activity per week, adjusted to your current ability.",
    why: "Regular activity supports blood pressure, lipid profile, insulin sensitivity and weight management together.",
    benefit: "Supports multiple findings at once rather than addressing each in isolation.",
    precaution: "Increase intensity gradually; stop and seek care if you experience chest pain, breathlessness or dizziness during activity.",
    followUp: "Reassess activity tolerance at your next review.",
    category: "activity", weight: 60,
  },
  {
    code: "REC_CV_SMOKING",
    domain: "cardiovascular",
    when: (fh) => fh.profile.smokingStatus === "Current smoker",
    issue: "Current smoking status",
    action: "Consider a structured smoking-cessation programme or speak with a pharmacist about cessation aids.",
    why: "Smoking is one of the largest modifiable contributors to cardiovascular risk in the risk calculators used by SQUARE.",
    benefit: "Cessation measurably reduces cardiovascular risk over time, independent of other findings.",
    precaution: "Cessation aids may not be suitable for everyone — a pharmacist or doctor can advise on the right approach.",
    followUp: "Revisit your risk score after 3–6 months smoke-free.",
    category: "lifestyle", weight: 97,
  },
  {
    code: "REC_MET_SUGAR",
    domain: "metabolic",
    when: (fh) => fh.metabolic.glucoseFlag,
    issue: "Fasting glucose / HbA1c above the illustrative reference range",
    action: "Reduce sugary drinks and refined carbohydrates, and space meals to avoid large glucose swings.",
    why: "Excess refined-carbohydrate intake is a common contributor to elevated glucose and HbA1c.",
    benefit: "May improve fasting glucose and HbA1c at the next check.",
    precaution: "If you take glucose-lowering medication, discuss dietary changes with your prescriber first.",
    followUp: "Repeat fasting glucose or HbA1c in 3 months.",
    category: "nutrition", weight: 80,
  },
  {
    code: "REC_LIVER_ALCOHOL",
    domain: "liver",
    when: (fh) => fh.liver.altFlag,
    issue: "ALT above the illustrative reference range",
    action: "Reduce alcohol intake and review any supplements or over-the-counter medication you take regularly.",
    why: "Alcohol, certain supplements and excess body weight are the most common contributors to a raised ALT.",
    benefit: "Liver enzymes often normalise within weeks once the contributing factor is addressed.",
    precaution: "Do not stop a prescribed medication without medical advice, even if you suspect it is contributing.",
    followUp: "Repeat liver function tests in 4–6 weeks.",
    category: "lifestyle", weight: 75,
  },
  {
    code: "REC_ANTHRO_WEIGHT",
    domain: "anthropometric",
    when: (fh) => fh.anthro.bmiCategory === "Overweight" || fh.anthro.bmiCategory === "Obese" || fh.anthro.waistFlag,
    issue: "Body mass index and waist circumference above the healthy range",
    action: "Work towards a gradual, sustainable reduction in weight and waist circumference through diet and activity together.",
    why: "Excess weight, particularly central adiposity, is a common upstream contributor to several of your other findings.",
    benefit: "Weight and waist reduction may improve blood pressure, lipids and glucose findings at the same time.",
    precaution: "Rapid or extreme weight loss is not advised without professional guidance, particularly with other medical conditions.",
    followUp: "Re-check weight and waist circumference monthly.",
    category: "lifestyle", weight: 85,
  },
  {
    code: "REC_GEN_SLEEP",
    domain: "general",
    when: () => true,
    issue: "General preventive health",
    action: "Aim for 7–9 hours of consistent, good-quality sleep.",
    why: "Poor sleep is linked with impaired glucose regulation, elevated blood pressure and reduced motivation for other healthy behaviours.",
    benefit: "Supports metabolic, cardiovascular and general wellbeing findings together.",
    precaution: "If you suspect a sleep disorder (e.g. loud snoring with witnessed pauses in breathing), mention this to a clinician.",
    followUp: "Track sleep for 2 weeks if unsure of your current pattern.",
    category: "sleep", weight: 40,
  },
];

/* ---- Explanation / health-education library (mirrors Module 16) ---- */
SQ.education = {
  EDU_LDL_001: "LDL carries cholesterol through the bloodstream. Higher levels may contribute to long-term cardiovascular risk when considered alongside your overall profile.",
  EDU_APOB_001: "Apolipoprotein B approximates the number of cholesterol-carrying particles in your blood, rather than the amount of cholesterol inside them — useful when it disagrees with your LDL-C result.",
  EDU_BP_001: "Blood pressure is the force of circulating blood against your artery walls. A single reading is a screening result; a pattern over several readings is more informative.",
  EDU_FRS_001: "The Framingham General Cardiovascular Risk Score estimates the chance of a major cardiovascular event over the next 10 years using age, sex, cholesterol, blood pressure, smoking and diabetes status. It is a population-based estimate, not a certainty for any one person.",
  EDU_LPA_001: "Lipoprotein(a), or Lp(a), is largely inherited and usually only needs to be measured once in adulthood. An elevated result modifies your overall risk but does not by itself diagnose cardiovascular disease.",
  EDU_GLUCOSE_001: "Fasting glucose and HbA1c both reflect how your body is managing blood sugar, over different timeframes — a single fasting reading versus an average over roughly three months.",
  EDU_ALT_001: "ALT is an enzyme mainly found in the liver. A raised level can reflect several different causes, most commonly alcohol, certain medications, or excess body weight.",
};

/* ---- Referral pathway content (Screen 15) ---- */
SQ.referralLevels = [
  {
    id: "emergency", label: "Emergency care", tone: "bad", rank: 1,
    description: "New severe chest pain, severe breathing difficulty, fainting, sudden weakness, facial droop or speech difficulty.",
    action: "Call local emergency services", urgent: true,
  },
  {
    id: "prompt", label: "Prompt medical review", tone: "warn", rank: 2,
    description: "Concerning symptoms, markedly abnormal repeat readings, or a result specifically flagged for early review.",
    action: "Seek medical advice soon",
  },
  {
    id: "routine", label: "Routine appointment", tone: "teal", rank: 3,
    description: "Discuss non-urgent findings, prevention targets and ongoing monitoring.",
    action: "Recommended for you",
  },
  {
    id: "self", label: "Wellness self-management", tone: "good", rank: 4,
    description: "Continue appropriate lifestyle actions and routine monitoring when no clinical review is indicated.",
    action: "View Action Plan",
  },
];
