/* EVA SQUARE — Trends "click to enlarge" interactive chart (Requirement #4).
 *
 * New for this FullStructure build. Clicking a quantity on the Trends
 * screen opens this modal: a canvas line chart the user can zoom (mouse
 * wheel / pinch) and pan (drag), with:
 *   - axis labels set in Times New Roman directly via canvas ctx.font
 *     (a CSS font-family can't reach canvas-drawn text, so this is done
 *     in JS, not style.css);
 *   - the plotted line coloured by the risk level of the quantity itself,
 *     as a smooth gradient built from the same tone vocabulary as the
 *     reference-scale bands (see js/ui/scaleRow.js / GET
 *     /api/meta/reference-scales) — canvas linear gradients interpolate
 *     between colour stops automatically, which gives the "smooth colour
 *     change" the spec asks for without hand-rolled interpolation;
 *   - a small formula readout rendered in Cambria Math (CSS class
 *     .trend-formula, see style.css) showing the linear trend fitted to
 *     the visible window.
 * X axis = date, Y axis = the quantity's value, per spec.
 */
window.SQ = window.SQ || {};
SQ.ui = SQ.ui || {};

(function () {
  "use strict";
  const U = () => SQ.ui;

  function cssVar(name, fallback) {
    try {
      const v = getComputedStyle(document.documentElement).getPropertyValue(name).trim();
      return v || fallback;
    } catch (e) { return fallback; }
  }

  function toneColor(tone) {
    if (tone === "good") return cssVar("--good", "#2f9e44");
    if (tone === "warn") return cssVar("--warn", "#b5650a");
    if (tone === "bad") return cssVar("--bad", "#c0392b");
    return cssVar("--teal", "#0f8c7f");
  }

  function toneForValue(scaleKey, value) {
    const scale = scaleKey && SQ.referenceScales ? SQ.referenceScales[scaleKey] : null;
    if (!scale || value == null) return "neutral";
    const band = (scale.bands || []).find((b) => value >= b.from && value <= b.to);
    return band ? band.tone : "neutral";
  }

  // Builds { lines: [{name, scaleKey, points:[{x:index, date, value}]}] }
  // from a /api/reports/:id/trends series for one key.
  function buildLines(key, seriesEntry) {
    const series = seriesEntry.series || [];
    if (key === "homeBP") {
      return [
        { name: "Systolic", scaleKey: "BP_SYSTOLIC", points: series.map((p, i) => ({ x: i, date: p.date, value: p.sbp })) },
        { name: "Diastolic", scaleKey: "BP_DIASTOLIC", points: series.map((p, i) => ({ x: i, date: p.date, value: p.dbp })) },
      ];
    }
    const scaleKey = SQ.labDictionary && SQ.labDictionary[key] ? key : null;
    const label = key === "weight" ? "Weight (kg)" : (SQ.labDictionary && SQ.labDictionary[key] ? SQ.labDictionary[key].name : key);
    return [{ name: label, scaleKey, points: series.map((p, i) => ({ x: i, date: p.date, value: p.value })) }];
  }

  function linearRegression(points) {
    const pts = points.filter((p) => p.value != null);
    const n = pts.length;
    if (n < 2) return null;
    const xs = pts.map((p) => p.x), ys = pts.map((p) => p.value);
    const xBar = xs.reduce((a, b) => a + b, 0) / n, yBar = ys.reduce((a, b) => a + b, 0) / n;
    let num = 0, den = 0;
    for (let i = 0; i < n; i++) { num += (xs[i] - xBar) * (ys[i] - yBar); den += (xs[i] - xBar) * (xs[i] - xBar); }
    const slope = den === 0 ? 0 : num / den;
    const intercept = yBar - slope * xBar;
    return { slope, intercept };
  }

  // ---- modal state ----
  let view = null; // { xMin, xMax, yMin, yMax }
  let dragging = null; // { startX, startY, view0 }
  let currentLines = null;
  let currentUnit = "";

  function dataBounds(lines) {
    let xMin = Infinity, xMax = -Infinity, yMin = Infinity, yMax = -Infinity;
    lines.forEach((line) => line.points.forEach((p) => {
      if (p.value == null) return;
      xMin = Math.min(xMin, p.x); xMax = Math.max(xMax, p.x);
      yMin = Math.min(yMin, p.value); yMax = Math.max(yMax, p.value);
    }));
    if (!isFinite(xMin)) { xMin = 0; xMax = 1; }
    if (!isFinite(yMin)) { yMin = 0; yMax = 1; }
    if (xMin === xMax) { xMin -= 1; xMax += 1; }
    const pad = (yMax - yMin) * 0.15 || 1;
    return { xMin: xMin - 0.5, xMax: xMax + 0.5, yMin: yMin - pad, yMax: yMax + pad };
  }

  function draw() {
    const canvas = document.getElementById("trend-canvas");
    if (!canvas || !currentLines || !view) return;
    const wrap = canvas.parentElement;
    const cssW = wrap.clientWidth, cssH = 380;
    const dpr = window.devicePixelRatio || 1;
    canvas.width = cssW * dpr; canvas.height = cssH * dpr;
    canvas.style.width = cssW + "px"; canvas.style.height = cssH + "px";
    const ctx = canvas.getContext("2d");
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, cssW, cssH);

    const padL = 58, padR = 18, padT = 18, padB = 40;
    const plotW = cssW - padL - padR, plotH = cssH - padT - padB;

    function xPix(x) { return padL + ((x - view.xMin) / (view.xMax - view.xMin)) * plotW; }
    function yPix(y) { return padT + plotH - ((y - view.yMin) / (view.yMax - view.yMin)) * plotH; }

    // gridlines + axis labels (Times New Roman, set directly on canvas —
    // this is the one place a font-family has to be applied in JS rather
    // than CSS, since canvas text ignores stylesheet fonts).
    ctx.strokeStyle = "#e3e7ef"; ctx.lineWidth = 1;
    ctx.fillStyle = "#64748b";
    ctx.font = "12px 'Times New Roman', Times, serif";
    ctx.textAlign = "right"; ctx.textBaseline = "middle";
    const yTicks = 5;
    for (let i = 0; i <= yTicks; i++) {
      const y = view.yMin + (i / yTicks) * (view.yMax - view.yMin);
      const py = yPix(y);
      ctx.beginPath(); ctx.moveTo(padL, py); ctx.lineTo(cssW - padR, py); ctx.stroke();
      ctx.fillText(Math.round(y * 100) / 100 + (currentUnit ? " " + currentUnit : ""), padL - 8, py);
    }

    // x labels: pick evenly spaced visible points
    const allDates = [];
    currentLines[0].points.forEach((p) => { allDates[p.x] = p.date; });
    ctx.textAlign = "center"; ctx.textBaseline = "top";
    const visibleFrom = Math.max(0, Math.floor(view.xMin)), visibleTo = Math.min(allDates.length - 1, Math.ceil(view.xMax));
    const span = Math.max(1, visibleTo - visibleFrom);
    const step = Math.max(1, Math.round(span / 6));
    for (let i = visibleFrom; i <= visibleTo; i += step) {
      if (allDates[i] == null) continue;
      ctx.fillText(allDates[i], xPix(i), cssH - padB + 8);
    }

    // axis lines
    ctx.strokeStyle = "#b9c2d0"; ctx.beginPath();
    ctx.moveTo(padL, padT); ctx.lineTo(padL, cssH - padB); ctx.lineTo(cssW - padR, cssH - padB); ctx.stroke();

    // clip to plot area so pan/zoom doesn't paint over axes
    ctx.save();
    ctx.beginPath(); ctx.rect(padL, padT, plotW, plotH); ctx.clip();

    currentLines.forEach((line, li) => {
      const pts = line.points.filter((p) => p.value != null);
      if (pts.length < 1) return;
      // gradient built from each point's risk tone — canvas interpolates
      // smoothly between the colour stops we add here.
      const grad = ctx.createLinearGradient(xPix(pts[0].x), 0, xPix(pts[pts.length - 1].x), 0);
      const denom = Math.max(1, pts.length - 1);
      pts.forEach((p, i) => {
        const tone = toneForValue(line.scaleKey, p.value);
        const stop = Math.min(1, Math.max(0, i / denom));
        try { grad.addColorStop(stop, toneColor(tone)); } catch (e) { /* out-of-range stop guard */ }
      });
      ctx.strokeStyle = pts.length > 1 ? grad : toneColor(toneForValue(line.scaleKey, pts[0].value));
      ctx.lineWidth = li === 0 ? 3 : 2;
      ctx.setLineDash(li === 0 ? [] : [6, 4]);
      ctx.beginPath();
      pts.forEach((p, i) => { const x = xPix(p.x), y = yPix(p.value); if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y); });
      ctx.stroke();
      ctx.setLineDash([]);
      pts.forEach((p) => {
        const tone = toneForValue(line.scaleKey, p.value);
        ctx.fillStyle = toneColor(tone);
        ctx.beginPath(); ctx.arc(xPix(p.x), yPix(p.value), li === 0 ? 4 : 3, 0, Math.PI * 2); ctx.fill();
        ctx.strokeStyle = "#fff"; ctx.lineWidth = 1.4; ctx.stroke();
      });
    });
    ctx.restore();
  }

  function clampView(v, bounds) {
    const minSpanX = (bounds.xMax - bounds.xMin) * 0.05;
    const maxSpanX = (bounds.xMax - bounds.xMin) * 3;
    let spanX = v.xMax - v.xMin;
    spanX = Math.max(minSpanX, Math.min(maxSpanX, spanX));
    let cx = (v.xMin + v.xMax) / 2;
    v.xMin = cx - spanX / 2; v.xMax = cx + spanX / 2;
    const minSpanY = (bounds.yMax - bounds.yMin) * 0.05;
    const maxSpanY = (bounds.yMax - bounds.yMin) * 3;
    let spanY = v.yMax - v.yMin;
    spanY = Math.max(minSpanY, Math.min(maxSpanY, spanY));
    let cy = (v.yMin + v.yMax) / 2;
    v.yMin = cy - spanY / 2; v.yMax = cy + spanY / 2;
    return v;
  }

  function wireInteractions(bounds) {
    const wrap = document.getElementById("trend-canvas-wrap");
    const canvas = document.getElementById("trend-canvas");
    if (!wrap || !canvas) return;

    wrap.addEventListener("wheel", (e) => {
      e.preventDefault();
      const rect = canvas.getBoundingClientRect();
      const mx = e.clientX - rect.left, my = e.clientY - rect.top;
      const padL = 58, padR = 18, padT = 18, padB = 40;
      const plotW = rect.width - padL - padR, plotH = rect.height - padT - padB;
      const dataX = view.xMin + ((mx - padL) / plotW) * (view.xMax - view.xMin);
      const dataY = view.yMax - ((my - padT) / plotH) * (view.yMax - view.yMin);
      const factor = e.deltaY > 0 ? 1.12 : 0.89;
      view.xMin = dataX - (dataX - view.xMin) * factor;
      view.xMax = dataX + (view.xMax - dataX) * factor;
      view.yMin = dataY - (dataY - view.yMin) * factor;
      view.yMax = dataY + (view.yMax - dataY) * factor;
      clampView(view, bounds);
      draw();
    }, { passive: false });

    wrap.addEventListener("mousedown", (e) => {
      dragging = { startX: e.clientX, startY: e.clientY, view0: Object.assign({}, view) };
    });
    window.addEventListener("mousemove", (e) => {
      if (!dragging) return;
      const rect = canvas.getBoundingClientRect();
      const padL = 58, padR = 18, padT = 18, padB = 40;
      const plotW = rect.width - padL - padR, plotH = rect.height - padT - padB;
      const dx = (e.clientX - dragging.startX) / plotW * (dragging.view0.xMax - dragging.view0.xMin);
      const dy = (e.clientY - dragging.startY) / plotH * (dragging.view0.yMax - dragging.view0.yMin);
      view.xMin = dragging.view0.xMin - dx; view.xMax = dragging.view0.xMax - dx;
      view.yMin = dragging.view0.yMin + dy; view.yMax = dragging.view0.yMax + dy;
      draw();
    });
    window.addEventListener("mouseup", () => { dragging = null; });

    // touch support (pinch not implemented; single-finger drag pans)
    let touchStart = null;
    wrap.addEventListener("touchstart", (e) => {
      if (e.touches.length === 1) touchStart = { x: e.touches[0].clientX, y: e.touches[0].clientY, view0: Object.assign({}, view) };
    }, { passive: true });
    wrap.addEventListener("touchmove", (e) => {
      if (!touchStart || e.touches.length !== 1) return;
      const rect = canvas.getBoundingClientRect();
      const padL = 58, padR = 18, padT = 18, padB = 40;
      const plotW = rect.width - padL - padR, plotH = rect.height - padT - padB;
      const dx = (e.touches[0].clientX - touchStart.x) / plotW * (touchStart.view0.xMax - touchStart.view0.xMin);
      const dy = (e.touches[0].clientY - touchStart.y) / plotH * (touchStart.view0.yMax - touchStart.view0.yMin);
      view.xMin = touchStart.view0.xMin - dx; view.xMax = touchStart.view0.xMax - dx;
      view.yMin = touchStart.view0.yMin + dy; view.yMax = touchStart.view0.yMax + dy;
      draw();
    }, { passive: true });
    wrap.addEventListener("touchend", () => { touchStart = null; });

    window.addEventListener("resize", draw);
  }

  function formulaHtml(lines) {
    const primary = lines[0];
    const reg = linearRegression(primary.points);
    if (!reg) return "";
    const trendWord = reg.slope > 0.001 ? "rising" : reg.slope < -0.001 ? "falling" : "flat";
    return `<div class="trend-formula">ŷ = ${reg.slope.toFixed(3)}x + ${reg.intercept.toFixed(2)}&nbsp;&nbsp;·&nbsp;&nbsp;Δ = y<sub>final</sub> − y<sub>initial</sub> = ${(primary.points.filter(p=>p.value!=null).slice(-1)[0].value - primary.points.filter(p=>p.value!=null)[0].value).toFixed(2)}&nbsp;&nbsp;·&nbsp;&nbsp;trend: ${trendWord}</div>`;
  }

  function open(key, seriesEntry, unit) {
    currentLines = buildLines(key, seriesEntry);
    currentUnit = unit || "";
    const bounds = dataBounds(currentLines);
    view = Object.assign({}, bounds);

    const label = key === "homeBP" ? "Blood pressure" : key === "weight" ? "Weight" : (SQ.labDictionary && SQ.labDictionary[key] ? SQ.labDictionary[key].name : key);
    const overlay = document.createElement("div");
    overlay.className = "modal-overlay";
    overlay.id = "trend-modal-overlay";
    overlay.innerHTML = `<div class="trend-modal">
      <div class="trend-modal-head">
        <div><h3>${U().esc(label)}</h3><div class="sub">Horizontal axis: date &nbsp;·&nbsp; Vertical axis: ${U().esc(label)}${unit ? " (" + U().esc(unit) + ")" : ""}. Line colour follows risk level.</div></div>
        <button type="button" class="trend-modal-close" onclick="SQ.ui.trendModal.close()">✕</button>
      </div>
      <div class="trend-modal-body">
        <div class="trend-canvas-wrap" id="trend-canvas-wrap"><canvas id="trend-canvas"></canvas></div>
        <div class="trend-modal-controls">
          <span class="trend-modal-hint">Scroll to zoom · drag to pan</span>
          <button type="button" class="btn outline sm" onclick="SQ.ui.trendModal.reset()">Reset view</button>
        </div>
        ${formulaHtml(currentLines)}
      </div>
    </div>`;
    overlay.addEventListener("click", (e) => { if (e.target === overlay) close(); });
    document.body.appendChild(overlay);

    requestAnimationFrame(() => { draw(); wireInteractions(bounds); });
    this._bounds = bounds;
    SQ.ui.trendModal._bounds = bounds;
  }

  function reset() {
    if (SQ.ui.trendModal._bounds) { view = Object.assign({}, SQ.ui.trendModal._bounds); draw(); }
  }

  function close() {
    const el = document.getElementById("trend-modal-overlay");
    if (el) el.remove();
    currentLines = null; view = null; dragging = null;
  }

  SQ.ui.trendModal = { open, close, reset };
})();
